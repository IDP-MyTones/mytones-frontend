export const fetchPage = () => {}

export const fetchTrack = () => {}
